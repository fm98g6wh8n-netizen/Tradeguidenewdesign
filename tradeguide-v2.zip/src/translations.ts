/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const TRANSLATIONS: Record<string, Record<string, string>> = {
  ko: {
    heroTitle: "세계 무역 조약을\n탐색하다.",
    heroSub: "복잡한 국제 무역 시나리오를 위한 우수한 법률 인텔리전스 워크스페이스. TRIPS 조약 프레임워크를 실질적인 분쟁 대응 전략으로 해독하고 조율합니다.",
    activeProtocol: "활성 분쟁 프로토콜",
    recentQueries: "최근 쿼리 이력",
    verificationNodes: "검증 및 준수 노드",
    monteCarlo: "몬테카를로 시뮬레이션",
    reset: "기본값 리셋",
    confidential: "국가 기밀 지정",
    searchPlaceholder: "조약 및 관세율 검색...",
    leadCounsel: "수석 고문 변호단",
    eliteIntelligence: "최정예 사법 인텔리전스",
    newScenario: "새 시나리오 개발",
    terminalPlaceholder: "명령어 입력('help' 또는 무역 분쟁 질의)...",
    execButton: "조회",
    statusText: "준수 상태 검증 기록"
  },
  en: {
    heroTitle: "Navigate \nThe Doctrine.",
    heroSub: "High-fidelity legal intelligence for complex international trade scenarios. Synthesizing TRIPS frameworks into actionable stratagem.",
    activeProtocol: "Active Protocol",
    recentQueries: "Recent Queries",
    verificationNodes: "Verification Nodes",
    monteCarlo: "Monte Carlo Run",
    reset: "Reset Defaults",
    confidential: "Confidential",
    searchPlaceholder: "Search doctrine...",
    leadCounsel: "Lead Counsel",
    eliteIntelligence: "Elite Intelligence",
    newScenario: "New Scenario",
    terminalPlaceholder: "Query doctrine or input parameters...",
    execButton: "EXEC",
    statusText: "Treaty Compliance Registries"
  }
};
