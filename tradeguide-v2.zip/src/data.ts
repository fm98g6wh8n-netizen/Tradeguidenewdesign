/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Scenario, QueryHistoryItem } from './types';

export const INITIAL_SCENARIOS: Scenario[] = [
  {
    id: 'ds353',
    title: 'WTO Dispute DS353',
    jurisdiction: 'Geneva',
    confidence: 94.2,
    status: 'Discovery Phase',
    summary: 'Analysis of the proposed unilateral tariff adjustments indicates a high probability of contravening GATT Article I (MFN). Recommend leveraging TRIPS Article 73 security exceptions if proceeding.',
    baselineVal: 40,
    propAVal: 70,
    propBVal: 85,
    category: 'Tariff Scenario Synthesis',
    confidentialFlag: true,
    queries: [
      'Article 27.1 non-discrimination analysis',
      'Patent enforcement flexibilities in LDCs',
      'MFN compatibility under GATT Article I'
    ],
    verificationNodes: [
      {
        id: 'node-1',
        title: 'DSB Precedent Match',
        description: 'Found 3 rulings aligning with current defense strategy.',
        type: 'verified',
        tags: ['US-Shrimp', 'EC-Asbestos']
      },
      {
        id: 'node-2',
        title: 'Expert Testimony Processing',
        description: 'Analyzing 450 pages of economic impact reports from independent trade analysts.',
        type: 'pending',
        progress: 35
      },
      {
        id: 'node-3',
        title: 'Tariff Schedule Alignment',
        description: 'Verifying conformance with specific Bound Tariffs registered in Geneva schedules.',
        type: 'verified',
        tags: ['Annex 1A', 'GATT 1994']
      }
    ]
  },
  {
    id: 'comp-license',
    title: 'TRIPS Art. 31bis Compulsory Licensing',
    jurisdiction: 'Brussels / Pretoria',
    confidence: 87.5,
    status: 'Litigation Prep',
    summary: 'Public health emergency framework requires invoking compulsory licensing under TRIPS Special Declaration on Public Health. Ensure compliance with export notifications under the 2003 waiver system.',
    baselineVal: 65,
    propAVal: 45,
    propBVal: 90,
    category: 'Compulsory Licensing Synthesis',
    confidentialFlag: true,
    queries: [
      'Compulsory licensing notification process',
      'Waiver system under Article 31 Paragraph f',
      'Exceptional circumstances public health declarations'
    ],
    verificationNodes: [
      {
        id: 'node-lc-1',
        title: 'Doha Declaration Conformance',
        description: 'Doha Declaration Paragraph 4 provides strong protective jurisdiction.',
        type: 'verified',
        tags: ['Doha 2001', 'Art. 31']
      },
      {
        id: 'node-lc-2',
        title: 'Importing LDC Capacity Review',
        description: 'Assessing pharmaceutical manufacturing capacity of offtaker countries.',
        type: 'pending',
        progress: 72
      },
      {
        id: 'node-lc-3',
        title: 'Inter-ministerial Vetting',
        description: 'Awaiting signature of executive decree under public healthcare emergency act.',
        type: 'alert',
        tags: ['Decree 12-A']
      }
    ]
  },
  {
    id: 'security-exception',
    title: 'GATT Art. XXI Security Exception',
    jurisdiction: 'Geneva / Washington',
    confidence: 79.1,
    status: 'Bilateral Negotiation',
    summary: 'Essential security interests declared regarding raw material exports. High precedence justification based on international relational emergency. Essential defense infrastructure exclusion is highly sustainable.',
    baselineVal: 30,
    propAVal: 80,
    propBVal: 55,
    category: 'Security Exception Synthesis',
    confidentialFlag: false,
    queries: [
      'Essential security interests precedent',
      'Russia-Traffic in Transit DS512 ruling',
      'Trade embargo national security grounds'
    ],
    verificationNodes: [
      {
        id: 'node-se-1',
        title: 'DS512 Precedent Deep Dive',
        description: 'Established international law jurisdiction over self-judging nature of Article XXI.',
        type: 'verified',
        tags: ['DS512', 'Transit Trade']
      },
      {
        id: 'node-se-2',
        title: 'Relational Emergency Audit',
        description: 'Analyzing diplomatic correspondence to demonstrate chronological emergency presence.',
        type: 'pending',
        progress: 50
      }
    ]
  }
];

export const INITIAL_QUERIES: QueryHistoryItem[] = [
  { id: 'q-1', queryText: 'Article 27.1 non-discrimination analysis', timestamp: '10m ago' },
  { id: 'q-2', queryText: 'Patent enforcement flexibilities in LDCs', timestamp: '35m ago' },
  { id: 'q-3', queryText: 'MFN treatment exemptions under GATT Art. XXIV', timestamp: '2h ago' },
  { id: 'q-4', queryText: 'Subsidies and Countervailing Measures (SCM) Article 3', timestamp: '1d ago' }
];
