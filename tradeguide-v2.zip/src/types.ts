/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface VerificationNode {
  id: string;
  title: string;
  description: string;
  type: 'verified' | 'pending' | 'alert';
  tags?: string[];
  progress?: number; // 0-100 for pending items
}

export interface Scenario {
  id: string;
  title: string;
  jurisdiction: string;
  confidence: number; // percentage (e.g. 94.2)
  status: string;
  summary: string;
  baselineVal: number; // height score 0-100
  propAVal: number;    // height score 0-100
  propBVal: number;    // height score 0-100
  category: string;
  confidentialFlag: boolean;
  queries: string[];
  verificationNodes: VerificationNode[];
}

export interface QueryHistoryItem {
  id: string;
  queryText: string;
  timestamp: string;
}
