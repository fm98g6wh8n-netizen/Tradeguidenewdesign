/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, FormEvent } from 'react';
import { X, Save, HelpCircle } from 'lucide-react';
import { Scenario } from '../types';

interface NewScenarioModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (newScenario: Scenario) => void;
}

export default function NewScenarioModal({ isOpen, onClose, onSave }: NewScenarioModalProps) {
  const [title, setTitle] = useState('');
  const [jurisdiction, setJurisdiction] = useState('');
  const [confidence, setConfidence] = useState(90);
  const [status, setStatus] = useState('Discovery Phase');
  const [category, setCategory] = useState('Custom Policy Synthesis');
  const [summary, setSummary] = useState('');
  const [confidential, setConfidential] = useState(true);

  if (!isOpen) return null;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !jurisdiction.trim() || !summary.trim()) {
      alert('Please fill out Title, Jurisdiction, and Analysis text.');
      return;
    }

    const id = 'custom-' + Date.now();
    const newSc: Scenario = {
      id,
      title: title.trim(),
      jurisdiction: jurisdiction.trim(),
      confidence: Number(confidence),
      status,
      summary: summary.trim(),
      baselineVal: 35,
      propAVal: 60,
      propBVal: 75,
      category: category.trim(),
      confidentialFlag: confidential,
      queries: ['Interim agreement feasibility', 'MFN exemption eligibility'],
      verificationNodes: [
        {
          id: id + '-v1',
          title: 'Custom Precedent Check',
          description: `Compliance query initiated for custom policy: "${title.trim()}"`,
          type: 'pending',
          progress: 5
        }
      ]
    };

    onSave(newSc);
    
    // reset form fields
    setTitle('');
    setJurisdiction('');
    setSummary('');
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fadeIn">
      <div 
        className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-lg p-6 relative shadow-[0_0_50px_rgba(184,114,44,0.15)] overflow-y-auto max-h-[90vh] no-scrollbar"
        onClick={(e) => e.stopPropagation()}
      >
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 text-[#d8c3b3]/60 hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          <X size={18} />
        </button>

        <div className="mb-6">
          <h2 className="font-serif text-xl font-bold text-[#ffb778]">Initiate Custom Legal Protocol</h2>
          <p className="text-[10px] text-[#d8c3b3]/50 uppercase tracking-widest font-mono mt-0.5">Define high-fidelity WTO compliance parameters</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[10px] font-bold uppercase text-[#d8c3b3]/80 tracking-wider mb-1.5">Dispute Title / Code</label>
            <input 
              type="text" 
              required
              placeholder="e.g., WTO Dispute DS590"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-lg text-xs text-white p-2.5 focus:outline-none focus:border-[#ffb778]"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-bold uppercase text-[#d8c3b3]/80 tracking-wider mb-1.5">Jurisdiction Space</label>
              <input 
                type="text" 
                required
                placeholder="e.g., Geneva / Tokyo"
                value={jurisdiction}
                onChange={(e) => setJurisdiction(e.target.value)}
                className="w-full bg-black/40 border border-white/10 rounded-lg text-xs text-white p-2.5 focus:outline-none focus:border-[#ffb778]"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase text-[#d8c3b3]/80 tracking-wider mb-1.5">Confidence Score (%)</label>
              <input 
                type="number" 
                min="10" 
                max="100"
                value={confidence}
                onChange={(e) => setConfidence(Number(e.target.value))}
                className="w-full bg-black/40 border border-white/10 rounded-lg text-xs text-white p-2.5 focus:outline-none focus:border-[#ffb778]"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-bold uppercase text-[#d8c3b3]/80 tracking-wider mb-1.5">Operational Phase</label>
              <select 
                value={status} 
                onChange={(e) => setStatus(e.target.value)}
                className="w-full bg-black/40 border border-white/10 rounded-lg text-xs text-white p-2.5 focus:outline-none focus:border-[#ffb778] cursor-pointer"
              >
                <option value="Discovery Phase">Discovery Phase</option>
                <option value="Litigation Prep">Litigation Prep</option>
                <option value="Bilateral Negotiation">Bilateral Negotiation</option>
                <option value="Executive Review">Executive Review</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase text-[#d8c3b3]/80 tracking-wider mb-1.5 font-sans">Legal Domain Category</label>
              <input 
                type="text" 
                placeholder="e.g. Subsidy Scenario Synthesis"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-black/40 border border-white/10 rounded-lg text-xs text-white p-2.5 focus:outline-none focus:border-[#ffb778]"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase text-[#d8c3b3]/80 tracking-wider mb-1.5 font-sans">Counsel Legal Summary / Synthesis Analysis</label>
            <textarea 
              required
              rows={3}
              placeholder="Provide elite compliance summary analysis regarding GATT/TRIPS..."
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-lg text-xs text-white p-2.5 focus:outline-none focus:border-[#ffb778] resize-none"
            />
          </div>

          <div className="flex items-center gap-3 py-2 border-y border-white/5">
            <input 
              type="checkbox" 
              id="confidential"
              checked={confidential}
              onChange={(e) => setConfidential(e.target.checked)}
              className="w-3.5 h-3.5 accent-[#ffb778] bg-black border border-white/10 rounded"
            />
            <label htmlFor="confidential" className="text-xs text-[#d8c3b3] select-none cursor-pointer">
              Mark protocol as highly confidential (Forces secure display mode)
            </label>
          </div>

          <div className="flex justify-end gap-3.5 pt-2">
            <button 
              type="button" 
              onClick={onClose}
              className="px-4 py-2 bg-transparent text-xs text-[#d8c3b3] hover:text-white uppercase font-bold tracking-wider"
            >
              Cancel
            </button>
            <button 
              type="submit"
              className="px-4.5 py-2.5 bg-[#ffb778] text-[#4c2700] hover:bg-[#ffdcc1] rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all shadow-[0_4px_15px_rgba(184,114,44,0.15)]"
            >
              <Save size={14} />
              Commit Scenario
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
