/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LayoutDashboard, TrendingUp, Rss, FileText, Gavel, HelpCircle, LogOut, Plus } from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onNewScenarioClick: () => void;
}

export default function Sidebar({ currentTab, setCurrentTab, onNewScenarioClick }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', name: 'Dashboard', icon: LayoutDashboard },
    { id: 'analysis', name: 'Trade Analysis', icon: TrendingUp },
    { id: 'rag', name: 'RAG Feed', icon: Rss },
    { id: 'documents', name: 'Documents', icon: FileText },
    { id: 'strategy', name: 'Legal Strategy', icon: Gavel },
  ];

  return (
    <aside className="hidden md:flex flex-col h-full py-8 px-4 bg-[#111111]/90 backdrop-blur-2xl fixed left-0 top-0 w-64 z-40 border-r border-white/10 shadow-[0_0_20px_rgba(184,114,44,0.05)] pt-28">
      {/* Role / Counsel Profile */}
      <div className="mb-8 px-4 pt-4">
        <p className="text-xs font-semibold uppercase tracking-widest text-[#d8c3b3]">Lead Counsel</p>
        <p className="text-sm font-medium text-[#ffb778]">Elite Intelligence</p>
      </div>

      {/* New Scenario Quick Button */}
      <button
        onClick={onNewScenarioClick}
        className="mb-8 mx-4 hover:scale-[1.02] active:scale-[0.98] bg-[#ffb778] text-[#4c2700] py-3 px-4 rounded-lg text-xs font-semibold tracking-wider flex items-center justify-center gap-2 hover:bg-[#ffdcc1] transition-all duration-300 shadow-[0_4px_20px_rgba(184,114,44,0.25)]"
      >
        <Plus size={16} />
        NEW SCENARIO
      </button>

      {/* Main Nav Items */}
      <nav className="flex-1 flex flex-col gap-1.5 px-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentTab(item.id)}
              className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3.5 transition-all duration-300 text-xs font-semibold tracking-wide uppercase ${
                isActive
                  ? 'text-[#ffb778] border-r-2 border-[#ffb778] bg-[#ffb778]/5 translate-x-1'
                  : 'text-[#d8c3b3]/80 hover:bg-white/5 hover:text-[#ffb778]'
              }`}
            >
              <Icon size={16} className={isActive ? 'text-[#ffb778]' : 'text-[#d8c3b3]/70'} />
              {item.name}
            </button>
          );
        })}
      </nav>

      {/* Footer Nav Integration */}
      <div className="mt-auto flex flex-col gap-1 px-2 pt-6 border-t border-white/5">
        <button className="w-full text-left px-4 py-2.5 rounded-lg flex items-center gap-3.5 text-xs font-semibold tracking-wide uppercase text-[#d8c3b3]/70 hover:bg-white/5 hover:text-[#ffb778] transition-all duration-300">
          <HelpCircle size={15} />
          Support
        </button>
        <button className="w-full text-left px-4 py-2.5 rounded-lg flex items-center gap-3.5 text-xs font-semibold tracking-wide uppercase text-[#d8c3b3]/70 hover:bg-white/5 hover:text-red-400 hover:bg-red-500/5 transition-all duration-300">
          <LogOut size={15} />
          Logout
        </button>
      </div>
    </aside>
  );
}
