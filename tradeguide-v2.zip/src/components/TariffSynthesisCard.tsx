/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect, FormEvent } from 'react';
import { Play, RotateCcw, ShieldCheck, Terminal, HelpCircle } from 'lucide-react';
import { Scenario } from '../types';

interface TariffSynthesisCardProps {
  activeScenario: Scenario;
  onUpdateScenarioVals: (baseline: number, propA: number, propB: number) => void;
  onSubmitTerminalQuery: (qText: string) => void;
  terminalResult: string;
  setTerminalResult: (res: string) => void;
  queryInput: string;
  setQueryInput: (val: string) => void;
}

export default function TariffSynthesisCard({
  activeScenario,
  onUpdateScenarioVals,
  onSubmitTerminalQuery,
  terminalResult,
  setTerminalResult,
  queryInput,
  setQueryInput,
}: TariffSynthesisCardProps) {
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const resultEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll terminal log to bottom on results
  useEffect(() => {
    if (resultEndRef.current) {
      resultEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [terminalResult]);

  const handleSynthesizeAction = () => {
    setIsSynthesizing(true);
    setTimeout(() => {
      onUpdateScenarioVals(
        Math.floor(Math.random() * 40) + 10,
        Math.floor(Math.random() * 50) + 40,
        Math.floor(Math.random() * 45) + 55
      );
      setIsSynthesizing(false);
      setTerminalResult(
        `[SUCCESS] Recalculated legal coefficients.\n- Confidence adjusted to: ${(
          Math.random() * 8 + 89
        ).toFixed(1)}%\n- Conformance thresholds mapped to Geneva Bound Tariff schedules.\n` + terminalResult
      );
    }, 1500);
  };

  const handleResetAction = () => {
    onUpdateScenarioVals(40, 70, 85);
    setTerminalResult(`[INFO] Restored primary dispute model defaults.`);
  };

  const handleTerminalSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!queryInput.trim()) return;

    const trimmed = queryInput.trim();
    setQueryInput('');
    onSubmitTerminalQuery(trimmed);
  };

  return (
    <div className="flex flex-col gap-6 w-full">
      {/* Target Scenario Synthesis workspace with interactive parameters */}
      <div className="glass-panel p-6 md:p-8 rounded-2xl relative overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-br from-[#ffb778]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />

        <div className="flex justify-between items-start mb-6">
          <div>
            <h2 className="font-serif text-xl md:text-2.5xl font-bold text-[#ffb778] tracking-tight">
              {activeScenario.category}
            </h2>
            <p className="text-[10px] text-[#d8c3b3]/50 uppercase tracking-widest font-mono mt-1">
              Interactive Compliance Modeling Studio
            </p>
          </div>
          {activeScenario.confidentialFlag && (
            <span className="border border-white/10 px-3 py-1 bg-red-950/20 text-[9px] font-bold tracking-widest text-[#ffb4ab] rounded uppercase">
              Confidential
            </span>
          )}
        </div>

        {/* Dynamic adjusters for trade parameters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6 p-4 bg-[#141414] border border-white/5 rounded-xl">
          <div>
            <div className="flex justify-between text-[10px] uppercase font-bold text-[#d8c3b3]/70 mb-1.5">
              <span>Baseline Val</span>
              <span className="text-[#ffb778]">{activeScenario.baselineVal}%</span>
            </div>
            <input
              type="range"
              min="10"
              max="100"
              value={activeScenario.baselineVal}
              onChange={(e) =>
                onUpdateScenarioVals(
                  parseInt(e.target.value),
                  activeScenario.propAVal,
                  activeScenario.propBVal
                )
              }
              className="w-full accent-[#ffb778] bg-white/10 rounded-lg height-1 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-[10px] uppercase font-bold text-[#d8c3b3]/70 mb-1.5">
              <span>Proposal A (Prop. A)</span>
              <span className="text-[#ffb778]">{activeScenario.propAVal}%</span>
            </div>
            <input
              type="range"
              min="10"
              max="100"
              value={activeScenario.propAVal}
              onChange={(e) =>
                onUpdateScenarioVals(
                  activeScenario.baselineVal,
                  parseInt(e.target.value),
                  activeScenario.propBVal
                )
              }
              className="w-full accent-[#ffb778] bg-white/10 rounded-lg height-1 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-[10px] uppercase font-bold text-[#d8c3b3]/70 mb-1.5">
              <span>Proposal B (Prop. B)</span>
              <span className="text-[#ffb778]">{activeScenario.propBVal}%</span>
            </div>
            <input
              type="range"
              min="10"
              max="100"
              value={activeScenario.propBVal}
              onChange={(e) =>
                onUpdateScenarioVals(
                  activeScenario.baselineVal,
                  activeScenario.propAVal,
                  parseInt(e.target.value)
                )
              }
              className="w-full accent-[#ffb778] bg-white/10 rounded-lg height-1 cursor-pointer"
            />
          </div>
        </div>

        {/* Active Scenario Text Interpretation */}
        <p className="text-sm text-white/90 leading-relaxed bg-white/3 p-4 rounded-xl border border-white/5 mb-8">
          {activeScenario.summary}
        </p>

        {/* Graphic bar chart with custom 3D design and triggers */}
        <div className="relative pt-6">
          <div className="absolute right-0 top-0 flex gap-2.5">
            <button
              onClick={handleSynthesizeAction}
              disabled={isSynthesizing}
              className="text-[10px] font-bold text-[#4c2700] hover:text-[#4c2700]/90 px-3 py-1.5 rounded bg-[#ffb778] uppercase tracking-wider flex items-center gap-1.5 hover:bg-[#ffdcc1] transition-all"
            >
              <Play size={10} className="fill-current" />
              {isSynthesizing ? 'Synthesizing...' : 'Monte Carlo Run'}
            </button>
            <button
              onClick={handleResetAction}
              className="text-[10px] font-bold text-[#ffb778] hover:text-white border border-white/10 hover:border-white/20 px-3 py-1.5 rounded uppercase tracking-wider flex items-center gap-1.5 transition-all"
            >
              <RotateCcw size={10} />
              Reset
            </button>
          </div>

          <div className="h-56 mt-6 border-b border-l border-white/15 flex items-end justify-around pb-0 pl-2 pt-10 gap-4 relative">
            {/* Grid Line Visualizers */}
            <div className="absolute inset-x-0 border-t border-white/5 top-1/4 pointer-events-none" />
            <div className="absolute inset-x-0 border-t border-white/5 top-1/2 pointer-events-none" />
            <div className="absolute inset-x-0 border-t border-white/5 top-3/4 pointer-events-none" />

            {/* Baseline Bar */}
            <div
              style={{ height: `${activeScenario.baselineVal}%` }}
              className="w-16 bg-[#1f1f1f] border border-white/20 bar-3d-interactive relative group cursor-pointer"
            >
              <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-[#1f1f1f] border border-white/10 px-1.5 py-0.5 rounded text-[10px] font-mono font-medium text-[#d8c3b3] opacity-0 group-hover:opacity-100 transition-opacity z-10 whitespace-nowrap">
                Baseline: {activeScenario.baselineVal}%
              </div>
              <div className="absolute inset-0 bg-[#ffdcc1]/3 opacity-5 hover:opacity-15 transition-opacity" />
            </div>

            {/* Proposal A Bar */}
            <div
              style={{ height: `${activeScenario.propAVal}%` }}
              className="w-16 bg-[#ffb778]/15 border border-[#ffb778]/50 bar-3d-interactive relative group cursor-pointer shadow-[0_0_30px_rgba(184,114,44,0.1)]"
            >
              <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-[#1f1f1f] border border-[#ffb778]/30 px-1.5 py-0.5 rounded text-[10px] font-mono font-bold text-[#ffb778] opacity-0 group-hover:opacity-100 transition-opacity z-10 whitespace-nowrap">
                Prop A: {activeScenario.propAVal}%
              </div>
              <div className="absolute inset-0 bg-[#ffb778]/10 animate-pulse pointer-events-none" />
            </div>

            {/* Proposal B Bar */}
            <div
              style={{ height: `${activeScenario.propBVal}%` }}
              className="w-16 bg-[#6dd4ed]/15 border border-[#6dd4ed]/50 bar-3d-interactive relative group cursor-pointer"
            >
              <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-[#1f1f1f] border border-[#6dd4ed]/30 px-1.5 py-0.5 rounded text-[10px] font-mono font-bold text-[#6dd4ed] opacity-0 group-hover:opacity-100 transition-opacity z-10 whitespace-nowrap">
                Prop B: {activeScenario.propBVal}%
              </div>
            </div>
          </div>

          <div className="flex justify-around mt-4 text-[10px] font-mono tracking-widest uppercase text-[#d8c3b3]/50">
            <span>Current Baseline</span>
            <span>Proposal A</span>
            <span>Proposal B</span>
          </div>
        </div>
      </div>

      {/* Terminal Area Mimicking Command Mode */}
      <div className="glass-panel p-4 rounded-xl border-l-4 border-l-[#ffb778] flex flex-col gap-3">
        <form onSubmit={handleTerminalSubmit} className="flex items-center gap-3">
          <Terminal size={14} className="text-[#ffb778] shrink-0 animate-pulse" />
          <span className="font-mono text-xs text-[#ffb778] select-none">_&gt;</span>
          <input
            type="text"
            value={queryInput}
            onChange={(e) => setQueryInput(e.target.value)}
            className="bg-transparent w-full border-0 focus:ring-0 text-xs font-mono text-white placeholder:text-white/20 outline-none"
            placeholder="Type 'help' for commands, select recent query, or query compliance engine..."
          />
          <button
            type="submit"
            className="text-[10px] hover:text-[#ffb778] bg-white/5 border border-white/10 rounded px-2.5 py-1 text-white uppercase font-mono tracking-widest"
          >
            EXEC
          </button>
        </form>

        {/* Live Terminal Console logs/results */}
        <div className="bg-black/40 border border-white/5 p-4 rounded-lg font-mono text-xs text-[#d8c3b3]/90 max-h-48 overflow-y-auto space-y-2">
          <div className="flex justify-between items-center text-[10px] text-white/30 border-b border-white/5 pb-1 mb-2">
            <span>TERMINAL CONTROLLERS</span>
            <span className="flex items-center gap-1">
              <ShieldCheck size={10} /> Live Verification Mode
            </span>
          </div>
          <pre className="whitespace-pre-wrap leading-relaxed select-text font-mono">
            {terminalResult}
          </pre>
          <div ref={resultEndRef} />
        </div>
      </div>
    </div>
  );
}
