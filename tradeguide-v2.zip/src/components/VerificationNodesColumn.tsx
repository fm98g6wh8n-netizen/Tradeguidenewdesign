/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ShieldCheck, Loader2, AlertCircle, FileSearch } from 'lucide-react';
import { VerificationNode } from '../types';

interface VerificationNodesColumnProps {
  nodes: VerificationNode[];
  onNodeClick: (node: VerificationNode) => void;
}

export default function VerificationNodesColumn({ nodes, onNodeClick }: VerificationNodesColumnProps) {
  return (
    <div className="flex flex-col gap-5 w-full">
      <div className="border-b border-white/10 pb-4">
        <h3 className="font-serif text-lg font-bold text-white tracking-tight">
          Verification Nodes
        </h3>
        <p className="text-[10px] text-[#d8c3b3]/50 uppercase tracking-widest font-mono mt-0.5">
          TCR Treaty Compliance Registries
        </p>
      </div>

      <div className="space-y-4">
        {nodes.map((node) => {
          const isVerified = node.type === 'verified';
          const isPending = node.type === 'pending';
          const isAlert = node.type === 'alert';

          return (
            <div
              key={node.id}
              onClick={() => onNodeClick(node)}
              className="glass-panel p-4 rounded-xl flex items-start gap-4 cursor-pointer hover:bg-white/5 active:scale-[0.99] group/node relative overflow-hidden"
            >
              {/* Active hover decorative visual border */}
              <div className="absolute left-0 inset-y-0 w-0.5 bg-[#ffb778] scale-y-0 group-hover/node:scale-y-100 transition-transform origin-center" />

              <div className="mt-1 shrink-0">
                {isVerified && (
                  <ShieldCheck size={18} className="text-[#ffb778]" />
                )}
                {isPending && (
                  <Loader2 size={18} className="text-[#6dd4ed] animate-spin" />
                )}
                {isAlert && (
                  <AlertCircle size={18} className="text-[#ffb4ab]" />
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-start gap-2">
                  <h4 className="text-xs font-semibold text-white leading-normal group-hover/node:text-[#ffb778] transition-colors">
                    {node.title}
                  </h4>
                  <span className="text-[8px] uppercase font-mono px-1.5 py-0.5 rounded bg-white/5 text-[#d8c3b3]/60">
                    {node.type}
                  </span>
                </div>

                <p className="text-[11px] text-[#d8c3b3]/80 mt-1.5 leading-relaxed">
                  {node.description}
                </p>

                {/* Progress rendering for pending nodes */}
                {isPending && typeof node.progress === 'number' && (
                  <div className="mt-3.5">
                    <div className="flex justify-between text-[9px] font-mono text-[#6dd4ed] mb-1">
                      <span>Syncing Registry Data...</span>
                      <span>{node.progress}%</span>
                    </div>
                    <div className="w-full bg-[#1b1b1b] border border-white/5 h-1.5 rounded-full overflow-hidden">
                      <div
                        style={{ width: `${node.progress}%` }}
                        className="bg-[#6dd4ed] h-full rounded-full transition-all duration-500"
                      />
                    </div>
                  </div>
                )}

                {/* Tags presentation */}
                {node.tags && node.tags.length > 0 && (
                  <div className="mt-3.5 flex flex-wrap gap-1.5">
                    {node.tags.map((tag) => (
                      <span
                        key={tag}
                        className="bg-white/5 border border-white/10 px-2 py-0.5 text-[9px] font-mono text-[#d8c3b3]/70 rounded uppercase"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {nodes.length === 0 && (
          <div className="text-center py-8 bg-white/3 border border-dashed border-white/10 rounded-xl">
            <FileSearch size={24} className="mx-auto text-white/20 mb-2" />
            <p className="text-xs text-[#d8c3b3]/50">No Active Verification Nodes mapped to scenario.</p>
          </div>
        )}
      </div>
    </div>
  );
}
