/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { X, CheckCircle, Clock, AlertTriangle, HelpCircle } from 'lucide-react';
import { VerificationNode } from '../types';

interface NodeDetailModalProps {
  node: VerificationNode | null;
  onClose: () => void;
}

export default function NodeDetailModal({ node, onClose }: NodeDetailModalProps) {
  if (!node) return null;

  const isVerified = node.type === 'verified';
  const isPending = node.type === 'pending';
  const isAlert = node.type === 'alert';

  return (
    <div 
      className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn"
      onClick={onClose}
    >
      <div 
        className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-md p-6 relative shadow-[0_0_30px_rgba(109,212,237,0.1)]"
        onClick={(e) => e.stopPropagation()}
      >
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 text-[#d8c3b3]/60 hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          <X size={18} />
        </button>

        <div className="flex items-center gap-2.5 mb-4 pb-2 border-b border-white/5">
          {isVerified && (
            <CheckCircle size={20} className="text-[#ffb778]" />
          )}
          {isPending && (
            <Clock size={20} className="text-[#6dd4ed] animate-pulse" />
          )}
          {isAlert && (
            <AlertTriangle size={20} className="text-[#ffb4ab]" />
          )}
          <div>
            <span className="text-[10px] uppercase font-bold text-[#d8c3b3]/50 tracking-widest font-mono">Dispute Registry File</span>
            <h3 className="text-sm font-bold text-white leading-tight">{node.title}</h3>
          </div>
        </div>

        <div className="space-y-4 text-xs font-sans">
          <div>
            <label className="block text-[10px] font-bold uppercase text-[#d8c3b3]/50 tracking-wider mb-1">Status Classification</label>
            <span className={`inline-block text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
              isVerified ? 'bg-[#ffb778]/10 text-[#ffb778]' : isPending ? 'bg-[#6dd4ed]/15 text-[#6dd4ed]' : 'bg-[#ffb4ab]/10 text-[#ffb4ab]'
            }`}>
              {node.type}
            </span>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase text-[#d8c3b3]/50 tracking-wider mb-1">Factual Compliance Record</label>
            <p className="text-[#e2e2e2] leading-relaxed font-normal bg-black/20 p-3 rounded-lg border border-white/5">
              {node.description}
            </p>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase text-[#d8c3b3]/50 tracking-wider mb-1.5">Enforcement Mechanisms Mapped</label>
            <div className="flex flex-wrap gap-1.5">
              {node.tags && node.tags.length > 0 ? (
                node.tags.map((tag) => (
                  <span 
                    key={tag}
                    className="bg-white/5 border border-white/10 px-2 py-0.5 text-[9px] font-mono font-semibold text-[#d8c3b3] rounded uppercase"
                  >
                    {tag}
                  </span>
                ))
              ) : (
                <span className="text-white/30 italic text-[11px]">No tags mapped to register node.</span>
              )}
            </div>
          </div>

          <div className="bg-[#1f1f1f] p-3 rounded-lg text-[10px] text-[#d8c3b3]/70 font-mono leading-relaxed border border-white/5">
            <span className="font-bold text-[#ffb778]">COUSEL GUIDANCE:</span> Treaty compliance elements are logged via distributed validation checkpoints in international trade repositories.
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button 
            onClick={onClose}
            className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white rounded text-xs font-bold uppercase tracking-wider transition-colors"
          >
            Acknowledge Registry
          </button>
        </div>
      </div>
    </div>
  );
}
