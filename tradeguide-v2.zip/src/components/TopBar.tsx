/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Search, Bell, Settings } from 'lucide-react';

interface TopBarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  notificationsCount: number;
  resetNotifications: () => void;
  onSettingsClick: () => void;
}

export default function TopBar({
  currentTab,
  setCurrentTab,
  searchTerm,
  setSearchTerm,
  notificationsCount,
  resetNotifications,
  onSettingsClick,
}: TopBarProps) {
  const [showNotificationDropdown, setShowNotificationDropdown] = useState(false);

  const mockNotifications = [
    { id: 1, text: "WTO Panel released updated compliance briefing for DS353.", read: false },
    { id: 2, text: "Compulsory licensing export declaration validated.", read: true },
    { id: 3, text: "High priority TRIPS legal precedent identified.", read: true }
  ];

  return (
    <header className="bg-[#0b0b0b]/80 backdrop-blur-xl fixed top-0 w-full z-50 border-b border-white/10 flex justify-between items-center px-4 md:px-12 py-4">
      <div className="flex items-center gap-8">
        <h1 
          onClick={() => setCurrentTab('dashboard')} 
          className="font-serif text-2xl md:text-3xl font-bold text-[#ffb778] tracking-tighter cursor-pointer hover:opacity-90 transition-opacity"
          style={{ textShadow: '0 0 16px rgba(184, 114, 44, 0.4)' }}
        >
          TradeGuide <span className="font-sans font-light text-sm tracking-widest text-[#d8c3b3]/80 align-super ml-1">v2</span>
        </h1>
        
        {/* Horizontal Navigation for desktop */}
        <nav className="hidden lg:flex gap-6 items-center pt-1.5 ml-4">
          {['intelligence', 'scenarios', 'library', 'archive'].map((tab) => (
            <button
              key={tab}
              onClick={() => setCurrentTab(tab)}
              className={`text-xs uppercase font-semibold tracking-wider transition-colors duration-300 ${
                currentTab === tab 
                  ? 'text-[#ffb778]' 
                  : 'text-[#d8c3b3]/80 hover:text-[#ffb778]'
              }`}
            >
              {tab}
            </button>
          ))}
        </nav>
      </div>

      <div className="flex items-center gap-4 md:gap-6">
        {/* Search Input Box */}
        <div className="relative hidden md:flex items-center bg-white/5 border border-white/10 hover:border-white/20 px-4 py-1.5 rounded-full transition-all">
          <Search size={14} className="text-[#d8c3b3]/60 mr-2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-transparent border-0 text-xs text-white focus:outline-none focus:ring-0 w-44 lg:w-56 placeholder:text-[#d8c3b3]/40"
            placeholder="Search doctrine or treaty..."
          />
          {searchTerm && (
            <button 
              onClick={() => setSearchTerm('')} 
              className="text-xs text-[#d8c3b3]/50 hover:text-[#ffb778] ml-2"
            >
              clear
            </button>
          )}
        </div>

        {/* Dynamic Notification Hub */}
        <div className="relative">
          <button 
            onClick={() => {
              setShowNotificationDropdown(!showNotificationDropdown);
              if (notificationsCount > 0) resetNotifications();
            }}
            className="text-[#d8c3b3]/80 hover:text-[#ffb778] p-1.5 rounded-lg hover:bg-white/5 transition-all relative"
          >
            <Bell size={18} />
            {notificationsCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-orange-500 animate-ping"></span>
            )}
            {notificationsCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-orange-500"></span>
            )}
          </button>

          {showNotificationDropdown && (
            <div className="absolute right-0 mt-3 w-80 bg-[#161616] border border-white/15 rounded-xl shadow-2xl p-4 z-50 text-xs">
              <div className="flex justify-between items-center pb-2 border-b border-white/10 mb-2">
                <span className="font-semibold text-[#ffb778] uppercase tracking-wider">Intelligence Briefings</span>
                <button onClick={() => setShowNotificationDropdown(false)} className="text-[#d8c3b3]/50 hover:text-white">Close</button>
              </div>
              <div className="space-y-3 pt-1">
                {mockNotifications.map((n) => (
                  <div key={n.id} className="p-2.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
                    <p className="text-[#e2e2e2] leading-relaxed">{n.text}</p>
                    <div className="mt-1 flex justify-between items-center text-[10px] text-[#d8c3b3]/50">
                      <span>Precedent System</span>
                      {!n.read && <span className="text-[#ffb778] font-bold">NEW</span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Global Settings Click */}
        <button 
          onClick={onSettingsClick}
          className="text-[#d8c3b3]/80 hover:text-[#ffb778] p-1.5 rounded-lg hover:bg-white/5 transition-all"
        >
          <Settings size={18} />
        </button>

        {/* User Profile Avatar with custom state */}
        <div className="h-9 w-9 md:h-10 md:w-10 rounded-full border border-[#ffb778]/30 overflow-hidden shrink-0 shadow-[0_0_10px_rgba(184,114,44,0.15)]">
          <img
            alt="User profile avatar"
            className="w-full h-full object-cover"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuCmsVYPjULOQuvfjS7KCJ7z0Dxc2je9_FlCi7CNdR737yw-FVOiIQ7YxM5vvH5-AtW_9_2wNpk96GwKlflEozC4KLyhZUrga6RatF531-dGHyxnZSgtds4rAMd_heOwuF-WNKIgHyqtwrKfmeYZUm9gaPVcKAF8Mf9c9Wd-CrZJPykXiaNNFkGO9ZhfLo2nP9pJAcLpDQBrppmOiUU_i5xDGdZH9wFoRxlbIwszsqtTKgryCAuUSAYzBrFlZ_HSYuaer7JdirvA1qk-"
            referrerPolicy="no-referrer"
          />
        </div>
      </div>
    </header>
  );
}
