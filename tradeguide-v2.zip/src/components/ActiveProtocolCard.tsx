/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Clock, Compass, TrendingUp, AlertTriangle } from 'lucide-react';
import { Scenario, QueryHistoryItem } from '../types';

interface ActiveProtocolCardProps {
  activeScenario: Scenario;
  recentQueries: QueryHistoryItem[];
  onQueryClick: (qText: string) => void;
  allScenarios: Scenario[];
  onSelectScenario: (scenario: Scenario) => void;
}

export default function ActiveProtocolCard({
  activeScenario,
  recentQueries,
  onQueryClick,
  allScenarios,
  onSelectScenario,
}: ActiveProtocolCardProps) {
  return (
    <div className="flex flex-col gap-6 w-full">
      {/* Active Scenario Selector Panel */}
      <div className="glass-panel p-6 rounded-xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-24 h-24 bg-[#ffb778]/5 rounded-bl-full pointer-events-none transition-all group-hover:bg-[#ffb778]/10" />
        
        <h3 className="text-[10px] font-bold uppercase tracking-widest text-[#d8c3b3] mb-4 border-b border-white/10 pb-2">
          Active Protocol
        </h3>
        
        {/* Dynamic drop-down scenario list selector */}
        <div className="mb-4">
          <label className="block text-[10px] text-[#d8c3b3]/50 uppercase tracking-wider mb-1">
            Selected Dispute Case
          </label>
          <select
            value={activeScenario.id}
            onChange={(e) => {
              const selectedSc = allScenarios.find(s => s.id === e.target.value);
              if (selectedSc) onSelectScenario(selectedSc);
            }}
            className="w-full bg-[#161616] border border-white/10 rounded-lg text-xs font-semibold text-[#ffb778] p-2 focus:outline-none focus:border-[#ffb778]/55 cursor-pointer"
          >
            {allScenarios.map((sc) => (
              <option key={sc.id} value={sc.id}>
                {sc.title}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2.5 mb-4">
          <div className="w-2.5 h-2.5 rounded-full bg-[#ffb778] animate-pulse shadow-[0_0_10px_#ffb778]" />
          <span className="text-xs font-semibold text-white tracking-wide">
            {activeScenario.title}
          </span>
        </div>

        {/* Detailed Stats Grid */}
        <div className="space-y-3 font-mono text-xs text-[#d8c3b3]/80">
          <div className="flex justify-between items-center py-0.5">
            <span className="flex items-center gap-1.5 text-[#d8c3b3]/50">
              <Compass size={12} />
              Jurisdiction:
            </span>
            <span className="text-white font-medium">{activeScenario.jurisdiction}</span>
          </div>
          
          <div className="flex justify-between items-center py-0.5">
            <span className="flex items-center gap-1.5 text-[#d8c3b3]/50">
              <TrendingUp size={12} />
              Confidence:
            </span>
            <span className="text-[#6dd4ed] font-bold">
              {activeScenario.confidence}%
            </span>
          </div>

          <div className="flex justify-between items-center py-0.5">
            <span className="flex items-center gap-1.5 text-[#d8c3b3]/50">
              <AlertTriangle size={12} className="text-[#ffb778]/80" />
              Status:
            </span>
            <span className="text-[#ffb778] font-semibold">{activeScenario.status}</span>
          </div>
        </div>

        {/* Interactive summary reveal */}
        <div className="mt-4 pt-4 border-t border-white/5">
          <p className="text-[10px] text-[#d8c3b3]/40 uppercase tracking-widest font-bold mb-1">Case Category</p>
          <span className="inline-block bg-[#ffb778]/10 text-[#ffb778] px-2.5 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider">
            {activeScenario.category.replace(' Synthesis', '')}
          </span>
        </div>
      </div>

      {/* Recent Queries Widget Box */}
      <div className="glass-panel p-6 rounded-xl">
        <h3 className="text-[10px] font-bold uppercase tracking-widest text-[#d8c3b3] mb-4 border-b border-white/10 pb-2">
          Recent Queries
        </h3>
        <div className="space-y-3.5 max-h-52 overflow-y-auto no-scrollbar">
          {recentQueries.map((item) => (
            <div
              key={item.id}
              onClick={() => onQueryClick(item.queryText)}
              className="flex items-start gap-2.5 p-1 rounded hover:bg-white/5 transition-all cursor-pointer group"
            >
              <Clock size={12} className="text-[#d8c3b3]/40 mt-1 group-hover:text-[#ffb778] shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs text-[#d8c3b3]/90 leading-relaxed font-medium group-hover:text-[#ffb778] transition-colors truncate">
                  {item.queryText}
                </p>
                <span className="text-[9px] text-white/30 font-mono tracking-wider">
                  {item.timestamp}
                </span>
              </div>
            </div>
          ))}

          {recentQueries.length === 0 && (
            <p className="text-xs text-[#d8c3b3]/40 italic text-center py-4">
              Query log is empty.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
