/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { X, Check } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: string;
  setLanguage: (lang: string) => void;
}

export default function SettingsModal({ isOpen, onClose, language, setLanguage }: SettingsModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fadeIn">
      <div 
        className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-sm p-6 relative shadow-[0_0_30px_rgba(184,114,44,0.15)]"
        onClick={(e) => e.stopPropagation()}
      >
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 text-[#d8c3b3]/60 hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          <X size={18} />
        </button>

        <div className="mb-6">
          <h2 className="font-serif text-lg font-bold text-[#ffb778]">Workspace Settings</h2>
          <p className="text-[10px] text-[#d8c3b3]/50 uppercase tracking-widest font-mono mt-0.5">Configure compliance parameters</p>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <span className="block text-[10px] uppercase font-bold text-[#d8c3b3]/50 tracking-wider">System Language</span>
            <div className="grid grid-cols-2 gap-2">
              <button 
                onClick={() => setLanguage('ko')}
                className={`flex items-center justify-between p-2.5 rounded-lg border text-xs font-semibold ${
                  language === 'ko' ? 'bg-[#ffb778]/15 border-[#ffb778] text-[#ffb778]' : 'bg-black/30 border-white/5 text-white/70 hover:border-white/10'
                }`}
              >
                <span>한국어 (Korean)</span>
                {language === 'ko' && <Check size={12} />}
              </button>

              <button 
                onClick={() => setLanguage('en')}
                className={`flex items-center justify-between p-2.5 rounded-lg border text-xs font-semibold ${
                  language === 'en' ? 'bg-[#ffb778]/15 border-[#ffb778] text-[#ffb778]' : 'bg-black/30 border-white/5 text-white/70 hover:border-white/10'
                }`}
              >
                <span>English (US)</span>
                {language === 'en' && <Check size={12} />}
              </button>
            </div>
          </div>

          <div className="p-3 bg-white/5 rounded-lg border border-white/5 text-[10px] text-[#d8c3b3]/60 font-mono leading-relaxed">
            <span className="font-bold text-[#6dd4ed]">COMPLIANCE ENGINE:</span> TradeGuide v2 operates with a sandboxed client-side compliance registry. All Monte Carlo recalculations are performed on current session structures.
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button 
            onClick={onClose}
            className="px-4 py-2 bg-[#ffb778] hover:bg-[#ffdcc1] text-[#4c2700] rounded text-xs font-bold uppercase tracking-wider transition-colors"
          >
            Apply Changes
          </button>
        </div>
      </div>
    </div>
  );
}
