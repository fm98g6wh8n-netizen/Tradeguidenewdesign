/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { ChevronDown, Sparkles } from 'lucide-react';
import { INITIAL_SCENARIOS, INITIAL_QUERIES } from './data';
import { Scenario, VerificationNode, QueryHistoryItem } from './types';
import { TRANSLATIONS } from './translations';

import Sidebar from './components/Sidebar';
import TopBar from './components/TopBar';
import ActiveProtocolCard from './components/ActiveProtocolCard';
import TariffSynthesisCard from './components/TariffSynthesisCard';
import VerificationNodesColumn from './components/VerificationNodesColumn';
import NewScenarioModal from './components/NewScenarioModal';
import NodeDetailModal from './components/NodeDetailModal';
import SettingsModal from './components/SettingsModal';

export default function App() {
  const [language, setLanguage] = useState<'ko' | 'en'>('ko');
  const [currentTab, setCurrentTab] = useState('dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Scenarios state
  const [scenarios, setScenarios] = useState<Scenario[]>(INITIAL_SCENARIOS);
  const [activeScenario, setActiveScenario] = useState<Scenario>(INITIAL_SCENARIOS[0]);
  
  // Queries history
  const [recentQueries, setRecentQueries] = useState<QueryHistoryItem[]>(INITIAL_QUERIES);
  const [queryInput, setQueryInput] = useState('');
  const [terminalResult, setTerminalResult] = useState<string>(
    `[INFO] System online. Compliance engine initiated standard protocols.\n[READY] Listening for WTO treaty query inputs...`
  );

  // Modals state
  const [isNewScenarioOpen, setIsNewScenarioOpen] = useState(false);
  const [selectedNode, setSelectedNode] = useState<VerificationNode | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [notificationsCount, setNotificationsCount] = useState(1);

  const t = TRANSLATIONS[language];

  // Modify active scenario coefficient levels
  const handleUpdateScenarioVals = (baseline: number, propA: number, propB: number) => {
    const updatedScenarios = scenarios.map((sc) => {
      if (sc.id === activeScenario.id) {
        const payload = { ...sc, baselineVal: baseline, propAVal: propA, propBVal: propB };
        setActiveScenario(payload);
        return payload;
      }
      return sc;
    });
    setScenarios(updatedScenarios);
  };

  // Switch scenario picker
  const handleSelectScenario = (scenario: Scenario) => {
    setActiveScenario(scenario);
    setTerminalResult(
      `[INFO] Switched framework focus to: ${scenario.title}\n[JURISDICTION] Connected directly with ${scenario.jurisdiction} TCR records.\n- Confidence level: ${scenario.confidence}%\n- Conformance analysis completed successfully.`
    );
  };

  // Submit terminal inputs
  const handleSubmitTerminalQuery = (queryText: string) => {
    // Add to query logs
    const newQueryItem: QueryHistoryItem = {
      id: 'q-' + Date.now(),
      queryText,
      timestamp: 'Just now',
    };
    setRecentQueries([newQueryItem, ...recentQueries]);

    // Parse commands natively
    const lower = queryText.toLowerCase().trim();
    if (lower === 'help') {
      setTerminalResult(
        `[HELP] Mappeable console commands:\n- 'help' : Display this help registry.\n- 'list' : Outputs all loaded compliance scenarios.\n- 'status' : Checks connectivity status of distributed verification nodes.\n- 'reset' : Restoration of all primary coefficients.\n- [Plain Text / Legal Queries] : Initiates an intelligent legal search matching against selected compliance regulations.`
      );
    } else if (lower === 'list') {
      const scList = scenarios.map((s) => `- ${s.title} (${s.jurisdiction}) : Domain = "${s.category}"`).join('\n');
      setTerminalResult(`[SCENARIO DIRECTORY]\n${scList}`);
    } else if (lower === 'status') {
      const nodeList = activeScenario.verificationNodes
        .map((n) => `  * ${n.title} [Status: ${n.type}]`)
        .join('\n');
      setTerminalResult(`[NODE AUDIT REPORT]\nActive scenario nodes:\n${nodeList}`);
    } else if (lower === 'reset') {
      handleUpdateScenarioVals(40, 70, 85);
      setTerminalResult(`[RESET] Default coefficients restored successfully.`);
    } else {
      // Simulate intelligent response
      setTerminalResult(
        `[QUERY EXECUTION] Searching TRIPS and GATT archives for: "${queryText}"...\n` +
          `[ANALYZED] Matches found under Chapter IV Article 27.\n` +
          `[CONCLUSIONS] Proposed regulatory updates show a strong 89% alignment rate. Minor adjustments recommended for tariff binding scheduling (Prop. A).`
      );
    }
  };

  // Click query log to prefill/run
  const handleQueryClick = (qText: string) => {
    setQueryInput(qText);
    handleSubmitTerminalQuery(qText);
  };

  // Save a new custom scenario
  const handleSaveNewScenario = (newScenario: Scenario) => {
    setScenarios([...scenarios, newScenario]);
    setActiveScenario(newScenario);
    setNotificationsCount(prev => prev + 1);
    setTerminalResult(
      `[SCENARIO CREATED] Successfully registered custom case: "${newScenario.title}"\nJurisdiction: ${newScenario.jurisdiction}\nMonte Carlo initial vectors generated.`
    );
  };

  // Filter scenarios based on top bar search
  const filteredScenarios = scenarios.filter((sc) => {
    const scTerm = searchTerm.toLowerCase();
    return (
      sc.title.toLowerCase().includes(scTerm) ||
      sc.jurisdiction.toLowerCase().includes(scTerm) ||
      sc.summary.toLowerCase().includes(scTerm)
    );
  });

  return (
    <div className="min-h-screen flex flex-col font-sans bg-[#0d0d0d] text-[#e2e2e2] antialiased">
      {/* Dynamic atmospheric decoration blobs */}
      <div className="absolute top-[20%] left-1/2 -translate-x-1/2 ambient-glowing-blob" />
      <div className="absolute top-[60%] right-[10%] w-[400px] h-[400px] bg-sky-950/10 rounded-full blur-[80px] pointer-events-none" />

      {/* Header Bar */}
      <TopBar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        notificationsCount={notificationsCount}
        resetNotifications={() => setNotificationsCount(0)}
        onSettingsClick={() => setIsSettingsOpen(true)}
      />

      {/* Desktop Navigation Sidebar */}
      <Sidebar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        onNewScenarioClick={() => setIsNewScenarioOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 md:ml-64 pt-20 pb-24 relative z-10 flex flex-col px-4 md:px-12">
        
        {/* Cinematic Hero Landing Column */}
        <section className="relative min-h-[70vh] flex flex-col items-center justify-center overflow-hidden py-12">
          {/* Suspended legal book visual rendering */}
          <div className="absolute inset-0 flex items-center justify-center opacity-40 mix-blend-screen pointer-events-none transition-transform duration-700 hover:scale-105">
            <img
              alt="TRIPS & World Trade Law"
              className="w-[85%] max-w-4xl object-contain drop-shadow-[0_0_80px_rgba(184,114,44,0.3)]"
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuCEeqZ3FNJxs3DWXjliyAQFtsiGP2FN_QeLNCfjig5IB-AidAUgzMizlLXzqe-lY7Lt2bvLx2C5PyVofR-2HHkcnq-KFLXX8R_ENyEBxbKLw8RRki3bXCE_CiiXtD-ilITmi-DmH7Z_G__rgMcsdNOCks2Yvt341OIrkrvdOnzO4UOp1WMzcomBGpy5ERGIqsCJ93rdWUNDod_zOhy-51ZSYNice4rfZeEuL8VRsooE3nxEu0GZnR1pCaXSJxoKPZ0UhsOpzyzh3Dim"
              referrerPolicy="no-referrer"
            />
          </div>

          <div className="relative z-10 text-center mt-12 flex flex-col items-center max-w-3xl">
            {/* Lead Counsel Elite Tag */}
            <div className="mb-4 inline-flex items-center gap-1.5 px-3 py-1 bg-white/5 border border-white/10 rounded-full text-[10px] uppercase font-bold tracking-wider text-[#ffb778]">
              <Sparkles size={11} /> Registered Compliance Systems
            </div>

            <h2 className="font-serif text-[48px] md:text-[76px] font-bold text-[#ffb778] tracking-tighter leading-none mb-6">
              {t.heroTitle.split('\n').map((line, idx) => (
                <span key={idx} className="block">
                  {line}
                </span>
              ))}
            </h2>
            
            <p className="text-sm md:text-base text-[#d8c3b3]/90 leading-relaxed font-normal max-w-2xl text-center">
              {t.heroSub}
            </p>

            <div className="mt-8 animate-bounce opacity-60">
              <ChevronDown className="text-[#ffb778]" size={28} />
            </div>
          </div>
        </section>

        {/* Search Results Alert Strip */}
        {searchTerm && (
          <div className="mb-8 p-3 bg-[#ffb778]/10 border border-[#ffb778]/30 rounded-xl flex justify-between items-center text-xs">
            <span>Filtering records with term: <strong className="text-[#ffb778]">"{searchTerm}"</strong> ({filteredScenarios.length} matches found)</span>
            <button onClick={() => setSearchTerm('')} className="text-[#ffb778] underline cursor-pointer">Clear filters</button>
          </div>
        )}

        {/* 3-Column Interactive Dashboard Panel */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 w-full max-w-[1700px] mx-auto pt-4 scroll-unfold-v2">
          {/* Column 1: Active Protocol and Query Log */}
          <div className="lg:col-span-3 flex flex-col gap-6">
            <ActiveProtocolCard
              activeScenario={activeScenario}
              recentQueries={recentQueries}
              onQueryClick={handleQueryClick}
              allScenarios={filteredScenarios}
              onSelectScenario={handleSelectScenario}
            />
          </div>

          {/* Column 2: Dashboard central workspace controller */}
          <div className="lg:col-span-6 flex flex-col gap-6">
            <TariffSynthesisCard
              activeScenario={activeScenario}
              onUpdateScenarioVals={handleUpdateScenarioVals}
              onSubmitTerminalQuery={handleSubmitTerminalQuery}
              terminalResult={terminalResult}
              setTerminalResult={setTerminalResult}
              queryInput={queryInput}
              setQueryInput={setQueryInput}
            />
          </div>

          {/* Column 3: Verification status lists */}
          <div className="lg:col-span-3 flex flex-col gap-6">
            <VerificationNodesColumn
              nodes={activeScenario.verificationNodes}
              onNodeClick={(node) => setSelectedNode(node)}
            />
          </div>
        </section>
      </main>

      {/* Global Modals container */}
      <NewScenarioModal
        isOpen={isNewScenarioOpen}
        onClose={() => setIsNewScenarioOpen(false)}
        onSave={handleSaveNewScenario}
      />

      <NodeDetailModal
        node={selectedNode}
        onClose={() => setSelectedNode(null)}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        language={language}
        setLanguage={setLanguage}
      />

      {/* Footer credits with clean spacing */}
      <footer className="w-full text-center py-8 text-[10px] text-white/20 select-none border-t border-white/5 relative z-10 bg-[#0d0d0d]">
        <p>© 2026 TradeGuide v2 • Powered by Elite compliance frameworks.</p>
      </footer>
    </div>
  );
}
